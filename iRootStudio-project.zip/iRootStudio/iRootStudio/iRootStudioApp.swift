import SwiftUI

@main
struct iRootStudioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
