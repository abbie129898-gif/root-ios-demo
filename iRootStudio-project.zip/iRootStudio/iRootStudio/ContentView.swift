import SwiftUI

struct DeviceDiagnosticItem: Identifiable {
    let id = UUID()
    let title: String
    let value: String
    let status: String
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var isRunningCheck = false
    @State private var lastCheckTime = "Chưa kiểm tra"

    private let diagnostics: [DeviceDiagnosticItem] = [
        .init(title: "Thiết bị mục tiêu", value: "iPhone 14 Pro Max", status: "arm64"),
        .init(title: "Phiên bản iOS", value: "18.7.8 (22H352)", status: "Hỗ trợ"),
        .init(title: "Chế độ đóng gói", value: "Unsigned IPA (Payload)", status: "Sẵn sàng ký"),
        .init(title: "Trình cài đặt đích", value: "ESign / Cert + MobileProvision", status: "Yêu cầu ký")
    ]

    var body: some View {
        NavigationStack {
            List {
                Section("Tổng quan iRoot Studio") {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("iRoot Studio v1.0.0")
                            .font(.headline)
                        Text("Ứng dụng SwiftUI được đóng gói chuẩn cấu trúc thư mục Payload/iRootStudio.app cho iOS.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text("Lần kiểm tra gần nhất: \(lastCheckTime)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                }

                Section("Thông số môi trường") {
                    ForEach(diagnostics) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.title)
                                    .font(.body)
                                Text(item.value)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(item.status)
                                .font(.caption.bold())
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.blue.opacity(0.12))
                                .foregroundStyle(.blue)
                                .clipShape(Capsule())
                        }
                    }
                }

                Section("Tác vụ") {
                    Button {
                        runQuickCheck()
                    } label: {
                        HStack {
                            if isRunningCheck {
                                ProgressView()
                                    .padding(.trailing, 6)
                            }
                            Text(isRunningCheck ? "Đang kiểm tra cấu trúc..." : "Chạy kiểm tra nhanh")
                        }
                    }
                    .disabled(isRunningCheck)
                }
            }
            .navigationTitle("iRoot Studio")
        }
    }

    private func runQuickCheck() {
        isRunningCheck = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            lastCheckTime = Date().formatted(date: .omitted, time: .standard)
            isRunningCheck = false
        }
    }
}

#Preview {
    ContentView()
}
